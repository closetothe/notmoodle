
#include <iostream>
#include <string>

using namespace std;

int main()
{

struct time_waits_for_noone
{
  int hours;
  int minutes;
  int seconds;
  int elapsed_time;
};


time_waits_for_noone mytime1, mytime2;


cout << "Enter hh mm ss for first value of time please " ;
cin >>  mytime1.hours >> mytime1.minutes >> mytime1.seconds ;
mytime1.elapsed_time = mytime1.seconds + ( mytime1.minutes * 60) + (mytime1.hours * 60 * 60);

cout << "Enter hh mm ss for value value of time please " ;
cin >>  mytime2.hours >> mytime2.minutes >> mytime2.seconds ;
mytime2.elapsed_time = mytime2.seconds + ( mytime2.minutes * 60) + (mytime2.hours * 60 * 60);

cout << mytime1.elapsed_time << endl << mytime2.elapsed_time << endl;

if (mytime2.elapsed_time >= mytime1.elapsed_time)
{
 cout << mytime2.hours << " hours and " << mytime2.minutes << " minutes and " << mytime2.seconds <<
 " seconds represents a longer period of elapsed time " << endl;
}
else
{
 cout << mytime1.hours << " hours and " << mytime1.minutes << " minutes and " << mytime1.seconds <<
 " seconds represents a longer period of elapsed time " << endl;
}



return 0;
}


