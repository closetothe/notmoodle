#include <iostream>

void swap(int* const p1, int* const p2)
{
int temp;

temp = *p1;
*(p1) = *(p2);
*(p2) = temp;

}


int main()
{

int mick = 5;
int keith = 10;

int* const mick_pointer = &mick;
int* const keith_pointer = &keith;

cout << "Before swap: mick = " << mick << " keith = " << keith << endl;

swap(mick_pointer, keith_pointer);

cout << "After swap: mick = " << mick << " keith = " << keith << endl;


return 0;

}

