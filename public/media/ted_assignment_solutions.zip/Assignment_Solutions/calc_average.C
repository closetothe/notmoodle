// Author: Ted Obuchowicz
// Sept.
// file: 



#include <iostream>
#include <string>

using namespace std;



int main()
{

float sum = 0;
int students = 0;
float grade;
float avg;

while ( cin >> grade )
{
 sum = sum + grade;
 students++;
}

avg = sum/students;

cout << "Average is : " << avg << endl;
cout << "Total numbe rof students is " << students << endl;


return 0;
}


