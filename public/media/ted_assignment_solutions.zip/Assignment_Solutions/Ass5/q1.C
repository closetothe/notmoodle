#include <iostream>
#include <string>

using namespace std;




int  main()
{

 int my_array[6];
 
 for(int i = 0 ; i < 6 ; i++)
  {
    cout << "Enter an integer value for the array ";
    cin >> my_array[i];
  }

 cout << "The array elements and the addresses they are stored in are " << endl;

 for(int i = 0 ; i < 6 ; i++ )
   cout << "Element = " << my_array[i] << " stored at address " << &my_array[i] << endl;

// now swap the array in place

for (int i = 0 ; i < 6/2 ; i++)
  {
   int temp = my_array[i];
   my_array[i] = my_array[5-i];
   my_array[5-i] = temp;
  }

cout << "The reversed array elements and the addresses they are stored in are " << endl;

for(int i = 0 ; i < 6 ; i++ )
   cout << "Element = " << my_array[i] << " stored at address " << &my_array[i] << endl;

  


return 0;

}

  



