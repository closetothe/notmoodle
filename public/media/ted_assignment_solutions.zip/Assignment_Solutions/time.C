
#include <iostream>
#include <string>

using namespace std;

int main()
{

int hh, mm, ss;
int elapsed_time;

cout << "Enter hh mm ss please " ;
cin >> hh >> mm >> ss ;

elapsed_time = ss + ( mm * 60) + (hh * 60 * 60);

cout << "Elapsed time in seconds is " <<  elapsed_time << endl;


return 0;
}

