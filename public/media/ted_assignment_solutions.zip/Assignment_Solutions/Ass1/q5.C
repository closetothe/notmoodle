#include <iostream>
#include <string>

using namespace std;

int main()
{

int total_seconds;
int hours = 0;
int minutes = 0;
int seconds = 0;

cout << "Enter an elapsed time in seconds as a whole number ";
cin >> total_seconds;

while (total_seconds >= 3600)
{
 hours++;
 total_seconds = total_seconds - 3600;
}

while (total_seconds >= 60 )
{
 minutes++;
 total_seconds = total_seconds - 60;
}

seconds = total_seconds;

cout << hours << ":" << minutes << ":" << seconds << endl;



return 0;
}

