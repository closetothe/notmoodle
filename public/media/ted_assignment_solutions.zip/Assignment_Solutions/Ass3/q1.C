#include <iostream>
#include <string>
#include <cmath>

  
using namespace std;

int main()
{


int a,b,c ; // the three sides 
int s ; // half the perimeter
float area ;

cout << "enter the three sides" ;
cin >> a >> b >> c ;

if ( (a+b>c) && (b+c>a) && (a+c>b) )
 {
   s = ( a + b + c ) / 2.0;
   area = sqrt( s * (s-a) * (s-b) * (s-c));
   cout << "area = " << area << endl;
 }
else
  cout << "sides do not represent a triangle" << endl;

 


return 0;
}

