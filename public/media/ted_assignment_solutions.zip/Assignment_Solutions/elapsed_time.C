
#include <iostream>
#include <string>

using namespace std;

int main()
{

struct time_waits_for_noone
{
  int hours;
  int minutes;
  int seconds;
  int elapsed_time;
};


time_waits_for_noone mytime;


cout << "Enter hh mm ss please " ;
cin >>  mytime.hours >> mytime.minutes >> mytime.seconds ;

mytime.elapsed_time = mytime.seconds + ( mytime.minutes * 60) + (mytime.hours * 60 * 60);


cout << "Elapsed time in seconds is " <<  mytime.elapsed_time << endl;


return 0;
}


