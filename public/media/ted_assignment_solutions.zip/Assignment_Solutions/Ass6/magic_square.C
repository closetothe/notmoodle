

#include <iostream>
using namespace std;


bool unique( int magic_square[20][20], int size) 
{
 bool all_found = true ; // assume the passed array contains all the integers
                         // between 1 and size*size

 bool element_found;
 int element;
for( element = 1 ; element <= size*size ; element++)
{
  element_found = false;
 
  for(int row = 0 ; row < size ; row++)
    for(int col = 0 ; col < size ; col++)
    {
      if ( magic_square[row][col] == element)
       {
          element_found = true;
       }
    }
  
  // for debugging only
  if (! element_found)
   cout << "The number " << element << " is not found in the array." << endl;
   
  all_found = all_found && element_found;

} 

// for debugging purposes only

if (all_found)
  cout << "The array is unique." << endl;
else
  cout << "The array is not unique." << endl;

 
 return all_found;

}


int RowSum( int square[20][20], int size, int row_num)
{
 int total = 0;
 for ( int i = 0 ; i < size ; i++ )
 {
   total = total + square[row_num][i];
 }

// for debugging only
cout << "The total for row " << row_num << " is " << total << endl;

return total;
}

int ColSum(int square[20][20], int size, int col_num)
{
 int total = 0;
 for ( int i = 0 ; i < size ; i++ )
 {
   total = total + square[i][col_num];
 }

// for debugging only
cout << "The total for col " << col_num << " is " << total << endl;
return total;
}


int Left_Diagonal(int square[20][20], int size )
{
 int total = 0;
 for(int i = 0 ; i < size ; i++)
 {
   total = total + square[i][i];
 }

// for debugging 
cout << "Left = " << total << endl;

return total;
}

int Right_Diagonal(int square[20][20], int size )
{
 int total = 0;
 for(int i = 0 ; i < size ; i++)
 {
  total = total + square[i][size - 1 - i];
 }

// for debugging
cout << "Right = " << total << endl;

return total;
}


int main()
{


int Square[20][20] ; // the biggest square we will work with is 20 x 20

int size ; // the user will input this value to specify what the size of the 
           // array will be.



cout << "Please enter the size of the square array " ;
cin >> size;

// input the array elements;

for(int i = 0 ; i < size ; i++)
  for(int j = 0 ; j < size ; j++)
  {
     cout << "Enter an array element " ;
     cin >> Square[i][j];
  };


bool magic = true ;  // assume the square is a magic one

if (unique(Square, size))
{
    int checksum = RowSum(Square, size, 0);
    int RowNumber = 1;
    while( magic && RowNumber < size)
    {
        if (checksum != RowSum(Square, size,  RowNumber))
            magic = false;
        RowNumber++;
    }
    // now check the columns

//    checksum = ColSum(Square, size, 0);
//    this is an error.... it would potentially
//    allow for a matrix in which all the rows up to one sum, and
//    all the cloumns add up to another different sum to be magical,
//    when in fact it is not magical..


    int ColNumber = 0;
    while ( magic && ColNumber < size)
    {
        if ( checksum != ColSum(Square, size, ColNumber))
           magic = false;

        ColNumber++;
    }


    // now check the diagonals

    if (magic)
    {
      if ( checksum != Left_Diagonal(Square, size) )
        magic = false;
      if ( checksum != Right_Diagonal(Square, size) )
        magic = false;
    }

}
 else
     magic = false;




if (magic)
 cout << "The array is magical." << endl;
else
 cout << "The array is not magical." << endl;

return 0;

}





