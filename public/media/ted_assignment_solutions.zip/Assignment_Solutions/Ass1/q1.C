#include <iostream>
#include <string>

using namespace std;

int main()
{

cout << "Keith Richards is rock'n'roll." << endl;
cout << "Madonna can't play guitar." << endl;
cout << "This is my first C++ program." << endl;
cout << "Goodbye World." << endl;


return 0;
}

