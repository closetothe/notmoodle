// Author: Ted Obuchowicz
//  Jan. 4, 2009
// file: lowest_common_multiple.C



#include <iostream>
#include <string>

using namespace std;



int main()
{
int mick, keith;
int largest;
int lcm ;

cout << "Enter two integers: " ;
cin >> mick >> keith ;

lcm = 1; 
while ( (lcm % mick != 0) || (lcm % keith != 0) )
{
 lcm++;
}

cout << "Lowest common multiple is: " << lcm << endl;


return 0;
}


