// Author: Ted Obuchowicz
// Jan. 4, 2009
// file:  amicable.C
// finds all pairs of amicable numbers between 200 and 300
// The first few amicable pairs are: (220, 284), (1184, 1210), (2620, 2924), (5020, 5564)
// divisors of 220 are: 1, 2, 4, 5, 10, 11, 20, 22, 44, 55 and 110 which sum up to 284
// divisors of 284 are: 1, 2, 4, 71, 142 which sum up to 220
// hence the pair (220, 2840 are said to be AMICABLE
// just like (rock, roll) are amicable



#include <iostream>
#include <string>

using namespace std;



int main()
{

int mick, keith;
int sum_mick_divisors, sum_keith_divisors;

for(mick = 200 ; mick <= 6000; mick++)
{
 sum_mick_divisors = 0;
 for(int divisor = 1 ; divisor < mick ; divisor++)
 {

    if ( mick % divisor == 0 ) // we found a divisor of mick, so sum it up
    {
       sum_mick_divisors =  sum_mick_divisors + divisor;
    }
 } // mick divisor loop

// for debugging
// cout << "Mick = " << mick << " sum of mick divisors = " << sum_mick_divisors << endl;


  for(keith = mick + 1 ; keith <= 6000 ; keith++)
  {
    sum_keith_divisors = 0;
    for(int divisor = 1 ; divisor < keith ; divisor++)
    {
      if ( keith % divisor == 0 ) // we found a divisor of keith, so sum it up
      {
        sum_keith_divisors = sum_keith_divisors + divisor;
      }
    } // keith divisor loop
     
// cout << "Keith = " << keith << " sum of keith divisors = " << sum_keith_divisors << endl;

      if ( (sum_mick_divisors ==  keith) && ( sum_keith_divisors == mick ) ) // mick and keith are amicable!
      {
       cout <<  "(" << mick << "," << keith << ")" << " are amicable." << endl;
      }
  
 
  } // keith for loop

} // mick for loop
  
        



return 0;
}


