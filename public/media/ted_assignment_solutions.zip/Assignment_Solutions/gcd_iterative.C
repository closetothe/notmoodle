// Author: Ted Obuchowicz
// Jan. 30, 2009
// file:  gcd_iterative.C



#include <iostream>
#include <string>

using namespace std;



int main()
{

int num1, num2;
int smaller;
int gcd;

// read in the two numbers

cout << "Enter two integers " << endl;

cin >> num1 >> num2;

// find the smaller of the two

if ( num1 <= num2 )
  smaller = num1;
else
  smaller = num2;

// set gcd to be equal to 1 
// if we find any common divisors, we will update gcd

gcd = 1 ;

for(int i = 2  ;  i <= smaller ; i++)
{
  if ( (num1 % i == 0) && (num2 % i == 0 ) )
     gcd = i ;   // i is a divisor of both, so update vale of gcd
}

cout << "GCD is: " << gcd << endl;

return 0;
}


