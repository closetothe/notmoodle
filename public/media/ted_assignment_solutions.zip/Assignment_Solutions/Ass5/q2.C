
#include <iostream>
#include <cstdlib>  ; // needed for defintion of NULL 
using namespace std;

int main()
{

char plain_text[7] ;  // the array containing a character string to be encoded
char encoded_text[7]; // this array will store the encoded string

// enter the plain_text from keyboard
for(int i = 0 ; i < 6 ; i++)
{
  cout << "Enter a character " ;
  cin >> plain_text[i];
}

//plain_text[6] = '\0';
plain_text[6] =  NULL;

int key ; // the encoding 'key'
cout << "Enter the encoding key which is to be used " ;
cin >> key;

int i = 0; // this is the offset from the encoded pointer

while ( plain_text[i] != '\0')
{
  encoded_text[i] =   plain_text[i] + key  ;
  i++;
}

// now add the null terminator to the encoded array

encoded_text[i]  = '\0';

// print out the two arrays

cout << plain_text << endl;
cout << encoded_text << endl;

return 0;

}

   
