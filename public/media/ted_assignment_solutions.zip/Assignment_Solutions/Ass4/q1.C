#include <iostream>
#include <string>

using namespace std;



void write_vertical(int n);

int  main()
{
 int n;
 cout << "Enter the integer n " ;
 cin >> n;
 write_vertical(n);

 return 0;
}

void write_vertical(int n)
{
 if ( n < 10 )
 {
   cout << n << endl;
 }
 else
 {
   write_vertical( n /10 );
   cout << ( n % 10) << endl;
 }
}


  



