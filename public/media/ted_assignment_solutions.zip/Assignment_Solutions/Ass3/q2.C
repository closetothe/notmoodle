#include <iostream>
#include <string>
#include <cmath>

using namespace std;

int main()
{

float wind;
float temp;
float wind_chill ;

cout << "Enter wind speed in miles per hour " ;
cin >> wind ;

cout << "Enter temperature in Fahrenheit " ;
cin >> temp;

wind_chill = 0.0817 * (3.71 * sqrt(wind) +5.81 - 0.25 * sqrt(wind)) *
              (temp - 91.4) + 91.4 ;

cout << "Wind chill is " << wind_chill << endl;







return 0;
}

