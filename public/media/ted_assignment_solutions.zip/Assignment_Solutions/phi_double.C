// Author: Ted Obuchowicz
// Jan. 20, 2009
// example program illustrating use of
// loop and Fibonacci numbers to compute
// value of phi to some desired degree of precision


#include <iostream>
#include <string>
#include <cmath>
# include <iomanip>
using namespace std;



int main()
{

unsigned int previous = 1;
unsigned int current  = 1;
unsigned int sum;
sum = previous + current;



double phi_1 =  (double) previous / (double) current;
double phi_2 =  (double) sum / (double) current; 


// set 16 decimal place formatting for output
cout << showpoint << setprecision(16) << endl;


while ( fabs( phi_2 - phi_1 ) >= 0.00000000000001 )
{
 previous = current ;
 current = sum ;
 phi_1 = phi_2;
 sum = previous + current;
 phi_2 = (float) sum /  (float) current;
 cout << "phi_1 = " << phi_1 << "  phi_2 = " << phi_2 <<  endl;
}

cout << endl;
cout <<  "To obtain phi = " << phi_2 << " required to compute Fibonacci numbers  " << current << " and " << sum << endl;

 
 

return 0;
}


