#include <iostream>
#include <string>

using namespace std;

int main()
{

int number ;
cout << "enter a number" ;
cin >> number;

bool valid = true;
bool prime = true;

switch (number)
{
case 1: ;
case 2: ;
case 3: ;
case 4: ;
case 5: ;
case 6: ;
case 7: ;
case 8: ;
case 9: ;
case 10: break;
default: valid = false;
         break;
}

if ( ! valid )
  cout << "Enter a number between 1 and 10 bonehead! " << endl;
else
  {
  prime = true ;
  for(int i = 2 ; i < number; i++)
  {
    if (number % i == 0  )
       prime = false;
  }
   if (prime)
  cout << number << " is prime " << endl;
else
  cout << number << " is not prime " << endl;

 
  }



return 0;
}

