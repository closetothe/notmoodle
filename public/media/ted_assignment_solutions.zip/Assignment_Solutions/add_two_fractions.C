// Author: Ted Obuchowicz



#include <iostream>
#include <string>

using namespace std;


int lcm(int mick, int keith)
{

 int multiple = 1 ;
 while ( (multiple % mick != 0) || (multiple % keith != 0) )
{
 multiple++;
}
return multiple;

}

int gcd(int mick, int  keith)
{
  int smaller;
  int common_divisor;
  if ( mick <= keith )
  smaller = mick;
else
  smaller = keith;

// set gcd to be equal to 1 
// if we find any common divisors, we will update gcd

common_divisor = 1 ;

for(int i = 2  ;  i <= smaller ; i++)
{
  if ( (mick % i == 0) && ( keith % i == 0 ) )
     common_divisor = i ;   // i is a divisor of both, so update value of gcd
}

return common_divisor; 

}


int main()
{

struct fraction
{
 int numerator;
 int denominator;
};

fraction f1,f2,f3;

int lowest_common_mult, greatest_common_div;

cin >> f1.numerator >> f1.denominator >> f2.numerator >> f2.denominator;

cout << "First fraction is: ";
cout << f1.numerator << "/" <<  f1.denominator << endl;

cout << "Second fraction is: " ;
cout << f2.numerator << "/" <<  f2.denominator << endl;


lowest_common_mult = lcm(f1.denominator,f2.denominator);

cout << endl;
cout << "LCM is: " << lowest_common_mult << endl;


if ( f1.denominator == lowest_common_mult)
{
  f2.numerator = f2.numerator * ( lowest_common_mult / f2.denominator ) ;
  f2.denominator  = lowest_common_mult  ;
}

if (f2.denominator == lowest_common_mult)
{
 f1.numerator =  f1.numerator * (lowest_common_mult / f1.denominator);
 f1.denominator = lowest_common_mult ;
}

if ( ( f1.denominator != lowest_common_mult) && (f2.denominator != lowest_common_mult) )
{
 
 f1.numerator =  f1.numerator * ( lowest_common_mult / f1.denominator) ;
 f2.numerator = f2.numerator * ( lowest_common_mult / f2.denominator );
 f1.denominator = lowest_common_mult ;
 f2.denominator = lowest_common_mult ;
}

f3.numerator = f1.numerator + f2.numerator;
f3.denominator = lowest_common_mult;  // can also make equal to either f1.denom or f2.denom

// now reduce f3 by diving its numer and denom by the gcd of its numer , denom


greatest_common_div = gcd(f3.numerator,f3.denominator);

f3.numerator = f3.numerator / greatest_common_div;
f3.denominator  = f3.denominator / greatest_common_div;

// print out the fractions

cout << "To add the fractions, I did the following operations on them: " << endl << endl;
cout << f1.numerator << "/" << f1.denominator ;
cout << " + "  ;
cout << f2.numerator << "/" << f2.denominator  ; 
cout << " = " ;
cout << f3.numerator << "/" << f3.denominator ;
cout << " in most reduced form " << endl;









return 0;
}


