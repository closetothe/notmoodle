// Author: Ted Obuchowicz
//  Jan. 4, 2009
// file: lowest_common_multiple.C



#include <iostream>
#include <string>

using namespace std;

int cm(int mick, int keith)
{
int answer;
answer  = 1;
while ( (answer % mick != 0) || (answer % keith != 0) )
{
 answer++;
}

return answer;
}



int main()
{
int mick, keith;
int largest;
int lcm ;

cout << "Enter two integers: " ;
cin >> mick >> keith ;


cout << "Lowest common multiple is: " << cm(mick,keith) << endl;


return 0;
}


