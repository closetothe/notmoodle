#include <iostream>
#include <string>

using namespace std;

int sum(int, int);

int main()
{


int a, b;
cin >> a >> b;

cout << sum(a,b) << endl;

return 0;

}



int sum(int a, int b)
{

int smaller, larger;

if ( a <= b )
{
  smaller = a;
  larger = b;
}
else
{
  smaller = b;
  larger = a;
}

int s = 0;

for(int i = smaller ; i <= larger ; i++)
  s = s + i;

return s;
}




