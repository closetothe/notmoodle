// Author: Ted Obuchowicz
// Feb. 11, 2002
// example program illustrating use of



#include <iostream>
#include <string>

using namespace std;


int add(int m, int n)
{
if  ( m <= 0 )  
   if ( n <=  0 )
     return 0;
   else 
     return 1 + add(m, n-1);
else 
  return 1 + add(m-1, n);

  

}

int main()
{

int mick, keith;
cout << "Please enter two integers you wish to recursively add " ;
cin >> mick >> keith;
cout << add(mick, keith) << endl;

return 0;
}


