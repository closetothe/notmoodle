#include <iostream>
#include <string>

using namespace std;


int gcd(int mick, int keith)
{
 if ( mick % keith == 0)
  return keith;
 else
  return gcd(keith, mick % keith);
}

int main()
{

int a, b;
cin >> a >> b ;
cout <<  gcd(a,b) << endl;



return 0;
}

