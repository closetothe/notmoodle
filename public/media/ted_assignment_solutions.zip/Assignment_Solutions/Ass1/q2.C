#include <iostream>
#include <string>

using namespace std;

int main()
{

float fahrenheit;
float celsius;

cout << "Enter temperature in Fahrenheit" ;
cin >> fahrenheit;

celsius = (5.0/9.0) * (fahrenheit - 32.0);

cout << "is equal to " << celsius << " in degrees Celsius " << endl;




return 0;
}

