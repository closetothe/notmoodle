// Author: Ted Obuchowicz
// Sept.
// file: 



#include <iostream>
#include <string>

using namespace std;



int main()
{


int num1, num2;
int gcd;

cout << "Enter two integers " << endl;
cin >> num1 >> num2;


while ( num1 != num2 )
{
 if ( num1 >= num2 )
  num1 = num1 - num2 ;
 else
  num2 = num2 - num1;
}

gcd = num1;

cout <<  "GCD is: " << gcd << endl;

return 0;
}


