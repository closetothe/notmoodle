// Author: Ted Obuchowicz
// Feb. 20, 2002
// program which gnerates the minimum amount of coins
// for a given amount.
// Coins are the following: twonnie, loonie, quarter, dime, nickel, pennie.




#include <iostream>
#include <string>

using namespace std;



int main()
{


int amount;  
int balance;
int twonnie, loonie, quarter, dime, nickel, pennie;

twonnie = loonie = quarter = dime = nickel = pennie = 0;

cout << "Enter the amount as an integer number of cents " ;
cin >>  amount;

balance = amount;

while ( balance >= 200 ) 
{
 twonnie++;
 balance = balance - 200;
}

while (balance >= 100 )
{
 loonie++;
 balance = balance - 100;
}

while ( balance >= 25)
{
 quarter++;
 balance = balance - 25;
}

while ( balance >= 10 )
{
 dime++;
 balance = balance - 10;
}

while ( balance >= 5)
{
 nickel++;
 balance = balance -5;
}

pennie = balance;

cout << "Twonnie = " << twonnie << endl;
cout << "loonie = " << loonie << endl;
cout << "quarter = " << quarter << endl;
cout << "dime = " << dime << endl;
cout << "nickel = " << nickel << endl;
cout << "pennie = " << pennie << endl;


return 0;
}


