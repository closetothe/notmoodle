#include <iostream>
#include <string>

using namespace std;

int main()
{


int n;
int a, b;

int prod;

cout << "Enter the value of n " ;
cin >> n;

for (int i = 0 ; i < n ; i++)
{
  cout << "enter the values of a and b " ;
  cin >> a >> b;
  if ( b >= a )
    {
      prod = a;
      for(int i = a+1 ; i <= b ; i++)
        prod = prod * i;
      cout << "product is " << prod << endl;
    }
  else
    {
      prod = b;
      for(int i = b+1 ; i <= a ; i++)
        prod = prod * i;
      cout << "product is " << prod << endl;
    }
}  


return 0;
}

