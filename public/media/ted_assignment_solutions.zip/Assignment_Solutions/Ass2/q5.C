#include <iostream>
#include <string>

using namespace std;

int main()
{


float wgpa;
char letter_grade;
float credit_value;
float total_credits = 0.0;
float sum = 0.0;

cout << "Enter letter grade and number of credits please ";

while ( cin >>  letter_grade >> credit_value )
{
   total_credits = total_credits + credit_value;

   switch (letter_grade)
   {
     case 'A' : sum = sum + (4.3 * credit_value) ;
                break;
     case 'B' : sum = sum + (3.0 * credit_value);
                break;
     case 'C' : sum = sum + (2.0 * credit_value);
                break;
     case 'D' : sum = sum + (1.0 * credit_value);
                break;
     case 'F' : sum = sum + (0.0 * credit_value);
                break;
     default  : cout << "Invalid letter grade " << endl;
   }


 cout << "Enter letter grade and number of credits please ";


}

wgpa = sum / total_credits;

cout << endl;
cout << "This persons Weighted Grade Point Average is " << wgpa << endl;


return 0;
}

