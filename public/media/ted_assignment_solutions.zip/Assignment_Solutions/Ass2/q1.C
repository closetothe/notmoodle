#include <iostream>
#include <string>

using namespace std;

int main()
{


int value;
cin >> value;

if (value == 0) 
 cout << "the number is zero" << endl;
else if ( value < 0 ) 
 cout << "the number is less than zero" << endl;
else if ( value > 0 )
 cout << "the number is greater than zero" << endl;

 


return 0;
}

