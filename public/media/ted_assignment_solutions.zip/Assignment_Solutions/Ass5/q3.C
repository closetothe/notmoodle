#include <iostream>
using namespace std;


bool Equal(int arr1[], int arr2[], int size1, int size2)
{

 if ( size1 != size2 )
   return false ;  // the arrays cannot be identical if the sizes are unequal!
 else
  {
    for (int i = 0 ; i < size1 ; i++ )
       if (arr1[i] != arr2[i] )
            return false;
  }

return true;

}




int main()
{

int a[3] = { 1,2,3 } ;
int b[3] = { 1,2,4 } ;

if ( Equal(a,b, 3,3)  )
  cout << "They are the same " << endl;
else
  cout <<"Not the same " << endl;


return 0;

}

   
