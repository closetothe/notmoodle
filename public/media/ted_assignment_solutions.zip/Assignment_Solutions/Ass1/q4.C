#include <iostream>
#include <string>

using namespace std;

int main()
{


// one method of solving this problem is
// to exploit the truncation of any fractional
// part of a real number when it is assigned to
// an in

float number ; // the floating point number read in as input
int num ; 
float fractional_part ;

cout << "Please enter a floating point number " ;
cin >> number;

num = number ; // this will truncate the fractional part

fractional_part = number - num ;

cout << num << endl;
cout << fractional_part << endl;


return 0;
}

