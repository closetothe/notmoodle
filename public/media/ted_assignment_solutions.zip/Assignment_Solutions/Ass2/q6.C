#include <iostream>
#include <string>

using namespace std;

int main()
{


float quiz;
float mid1, mid2;
float final;
float percentage;
float highest = 0.0;
float lowest = 100.0;
float sum = 0.0;
float number_of_students = 0;
float average;

cout << "Please enter quiz grade, midterm1 grade , midterm2 grade and final ";

while (cin >> quiz >> mid1 >> mid2 >> final )
{
  percentage = (quiz * 0.15) + (mid1 * 0.15 ) + (mid2 * 0.35) + (final * 0.35);
  cout << "This student's percentage grade is : " << percentage << endl;
  sum = sum + percentage;
  number_of_students++;
  
  if (percentage >= highest )
    highest = percentage;

  if (percentage <= lowest )
    lowest = percentage;
 
  cout << "Please enter quiz grade, midterm1 grade , midterm2 grade and final ";


}



average = sum / number_of_students ;

cout << "The average grade is: " << average << endl;
cout << "The lowest grade is: " << lowest << endl;
cout << "The highest grade is: " << highest << endl;


return 0;
}

