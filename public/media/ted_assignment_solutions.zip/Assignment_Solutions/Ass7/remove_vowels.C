// Author: Ted Obuchowicz



#include <iostream>
#include <string>

using namespace std;

char* remove_vowels(char * str)
{
 int length = strlen(str);
 length++ ; // add one more to account for end-of-string character
 char * start = new char  [length] ; // dynamically allocate sufficient memory 
 char * tmp = start; // make a copy 
 while( * str != '\0')
 {
   if ((*str != 'a') && (*str != 'e') && (*str != 'i') && (*str != 'o') &&  (*str != 'u') )

    {
      *tmp = *str ; // copy the non-vowel characters
       tmp++;
    }

   str++; // advance the two pointers
 }
  *tmp =  '\0' ;  // add the end of string character to the end of the new string
  return start;
}


int main()
{

char s1[] = "xcvbnmhjk";
char s2[] = "";
char s3[] = "aeiou";
char s4[] = "hello";
char s5[] = "good";


cout << s1 << "   " << remove_vowels(s1) << endl;
cout << s2 << "   " << remove_vowels(s2) << endl;
cout << s3 << "   " << remove_vowels(s3) << endl;
cout << s4 << "   " << remove_vowels(s4) << endl;
cout << s5 << "   " << remove_vowels(s5) << endl;

return 0;
}


