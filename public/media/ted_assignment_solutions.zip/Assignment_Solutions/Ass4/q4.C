#include <iostream>
#include <string>

using namespace std;



int max(int, int);

float max(float, float);

int main()
{
 int max_int;
 float max_float;
 max_int = max(3,4);
 cout  << max_int << endl;
 max_float = max(4.0f, 5.0f);
 cout << max_float << endl;

 return 0; 
}

int max(int a, int b)
{
 if ( a >= b)
  return a;
 else
  return b;
}

float max(float a, float b)
{
 if ( a >= b)
  return a;
 else
  return b;
}




  



