#include <iostream>
#include <string>

using namespace std;

int main()
{

const int inches_per_mile = 5280 * 12 ;
const int inches_per_foot = 12;
int total_inches;
int miles = 0;
int feet = 0;
int inches;


cout << "Enter a distance in inches " ;
cin >> total_inches;

while ( total_inches >= inches_per_mile )
{
 miles++;
 total_inches = total_inches - inches_per_mile;
}

while (total_inches >= inches_per_foot)
{
 feet++;
 total_inches  = total_inches - inches_per_foot;
}

inches = total_inches ;


cout << "Miles = " << miles << endl;
cout << "Feet = " << feet << endl;
cout << "Inches = " << inches << endl;


return 0;
}

