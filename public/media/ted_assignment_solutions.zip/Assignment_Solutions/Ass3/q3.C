#include <iostream>
#include <string>

using namespace std;



void calculate( int mick, int keith, int ron, int charlie, int& sum, int& product);

int main()
{
  int a ,b,c,d, sum, prod;
  cin >> a >> b >> c >> d;
  calculate(a,b,c,d,sum, prod);
  cout << "Sum = " << sum << " Product = " << prod << endl;


return 0;
}

void calculate( int mick, int keith, int ron, int charlie, int& sum, int& product)
{
 sum = mick + keith + ron + charlie ;
 product = mick * keith * ron * charlie;
}



